﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Customer_menu_templates
{
    /// <summary>
    /// Interaction logic for customerWindow.xaml
    /// </summary>
    public partial class customerWindow : Window
    {
        // MySqlConnection is part of the MySQL Connector/NET library for connecting to MySQL databases.
        MySqlConnection conn;

        // Connection string that contains information like server, user, database, port, and password.
        // This string is used to establish a connection to the MySQL database.

        string connStr = "server=ND-COMPSCI;" + // Home server = 127.0.0.1 - Notre server = ND-COMPSCI
                         "user=" + "TL_S2201563" + ";" +
                         "database=" + "------" + ";" + // Change for whatever schema is given
                         "port=3306;" +
                         "password=" + "Notre151105" + ";";

        // Reference to the parent window that opened this customer window.
        Window parentWindow;

        // Global variable to store the user ID.
        string customerIDGlobal = "";

        // Constructor for the customerWindow class.
        // Takes the user ID and a reference to the parent window as parameters.
        public customerWindow(string customerID, Window parent)
        {
            // Hides the parent window.
            this.parentWindow = parent;
            parentWindow.Hide();

            // Initializes the components of the customer window.
            InitializeComponent();

            // Assigns the user ID to the global variable.
            customerIDGlobal = customerID;

            // Establishes a connection to the MySQL database to retrieve user information.
            conn = new MySqlConnection(connStr);
            conn.Open();

            //Retrieves and displays the user's first and last name.
            string userNameFind = "SELECT firstName, lastName FROM customers WHERE customerID = @customerId";
            MySqlCommand cmd = new MySqlCommand(userNameFind, conn);
            cmd.Parameters.AddWithValue("@customerId", int.Parse(customerID));
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                txtBlockWelcome.Text = $"Hello {rdr.GetString(0)} {rdr.GetString(1)}";
            }
            conn.Close();
        }


        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            // Creates a new instance of the MainWindow and shows it.
            MainWindow mainPage = new MainWindow();
            this.Close();
            mainPage.Show();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            // Creates a new instance of the MainWindow and shows it.
            MainWindow mainPage = new MainWindow();
            this.Close();
            mainPage.Show();
        }
    }
}
