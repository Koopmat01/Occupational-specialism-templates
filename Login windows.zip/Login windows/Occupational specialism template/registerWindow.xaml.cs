﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Occupational_specialism_template
{
    /// <summary>
    /// Interaction logic for registerWindow.xaml
    /// </summary>
    public partial class registerWindow : Window
    {
        MySqlConnection conn;
        string connStr = "server=ND-COMPSCI;" +
                         "user=" + "TL_S2201563" + ";" +
                         "database=" + "------" + ";" + // Change for what schema name is relevant
                         "port=3306;" +
                         "password=" + "Notre151105" + ";";

        Window parentWindow;

        // Constructor for the registerWindow class.
        // Takes a reference to the parent window as a parameter.
        public registerWindow(Window parent)
        {
            // Assigns the parameter to the respective variable.
            this.parentWindow = parent;
            parentWindow.Hide();
            InitializeComponent();
        }

        // Event handler for the "Home" button click.
        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            // Creates a new instance of the MainWindow and shows it.
            MainWindow mainPage = new MainWindow();
            this.Close();
            mainPage.Show();
        }

        // Method to check if a string contains only valid characters.
        public static bool validCharacterCheck(string checkVariable)
        {
            foreach (char character in checkVariable)
            {
                // Checks for invalid characters and returns false if found.
                if (character == ';' || character == ' ' || character == '"' || character == '\'')
                {
                    return false;
                }
            }
            // Returns true if the string contains only valid characters.
            return true;
        }

        // Event handler for the "Confirm Details" button click.
        private void btnConfirmDetails_Click(object sender, RoutedEventArgs e)
        {
            // Retrieves input values from text boxes.
            string username = txtBoxUsername.Text;
            string password = txtBoxPassword.Text;
            string firstName = txtBoxFirstName.Text;
            string lastName = txtBoxLastName.Text;
            string email = txtBoxEmail.Text;

            // Checks if any of the required fields are empty.
            if (username.Length == 0 || password.Length == 0 || firstName.Length == 0 || lastName.Length == 0 || email.Length == 0)
            {
                MessageBox.Show("You must input something in each box");
                return;
            }

            // Validates input characters for each field.
            bool validUsernameCheck = validCharacterCheck(username);
            bool validPasswordCheck = validCharacterCheck(password);
            bool validFirstNameCheck = validCharacterCheck(firstName);
            bool validLastNameCheck = validCharacterCheck(lastName);
            bool validEmailCheck = validCharacterCheck(email);

            // Displays an error message if invalid characters are found.
            if (validUsernameCheck == false || validPasswordCheck == false || validFirstNameCheck == false || validLastNameCheck == false || validEmailCheck == false)
            {
                MessageBox.Show("Please only include valid characters");
                return;
            }

            // Checks if input lengths exceed the specified limits.
            if (username.Length >= 25 || password.Length >= 25 || firstName.Length >= 25 || lastName.Length >= 25 || email.Length >= 45)
            {
                MessageBox.Show("You went over the character limit");
                return;
            }

            // Validates that the first name and last name contain only letters.
            if (Regex.IsMatch(firstName, "^[a-zA-Z]+$") == false || Regex.IsMatch(lastName, "^[a-zA-Z]+$") == false)
            {
                MessageBox.Show("Your name can't contain non-letter characters");
                return;
            }

            // Initializes variables for user ID generation.
            string userID = "C000";
            int userIDNum = 0;

            // Fetches the total number of ------ to generate a new user ID.
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            string countStatement = "SELECT COUNT(*) as total------ " + // Change for what table name is relevant
                "FROM ------"; // Change for what table name is relevant
            MySqlCommand cmd = new MySqlCommand(countStatement, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                userIDNum = rdr.GetInt32(0);
                userIDNum = userIDNum + 1;
                userID = "C" + userIDNum.ToString("000");
            }
            conn.Close();

            // Inserts the new customer into the database.
            conn = new MySqlConnection(connStr);
            conn.Open();
            string insertStatement = "INSERT INTO ------ " + // Change for what table name is relevant
                "VALUES " +
                "(@paramUserID,@paramFirstName,@paramLastName,@paramUsername, SHA2(@paramPassword,256) ,@paramEmail)";
            cmd = new MySqlCommand(insertStatement, conn);
            cmd.Parameters.AddWithValue("@paramUserID", userID);
            cmd.Parameters.AddWithValue("@paramFirstName", txtBoxFirstName.Text);
            cmd.Parameters.AddWithValue("@paramLastName", txtBoxLastName.Text);
            cmd.Parameters.AddWithValue("@paramUsername", txtBoxUsername.Text);
            cmd.Parameters.AddWithValue("@paramPassword", txtBoxPassword.Text);
            cmd.Parameters.AddWithValue("@paramEmail", txtBoxEmail.Text);


            try
            {
                // Executes the INSERT command.
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registration successful");
                MessageBox.Show("Your User ID: " + userID);



                // Change space for opening the new customer window


            }
            catch (Exception ex)
            {
                // Displays an error message if registration is unsuccessful.
                MessageBox.Show(ex.ToString());
                return;
            }
        }
    }
}

