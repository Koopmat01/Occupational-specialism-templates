﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Occupational_specialism_template
{
    /// <summary>
    /// Interaction logic for resetPasswordWindow.xaml
    /// </summary>
    public partial class resetPasswordWindow : Window
    {
        MySqlConnection conn;
        string connStr = "server=ND-COMPSCI;" +
                         "user=" + "TL_S2201563" + ";" +
                         "database=" + "------" + ";" + // Change for whatever schema name is correct
                         "port=3306;" +
                         "password=" + "Notre151105" + ";";

        Window parentWindow;

        // Constructor for the resetPasswordWindow class.
        // Takes a reference to the parent window as a parameter.
        public resetPasswordWindow(Window parent)
        {
            // Assigns the parameter to the respective variable.
            this.parentWindow = parent;
            parentWindow.Hide();
            InitializeComponent();
        }

        // Event handler for the "Reset Password" button click.
        private void btnResetPassword_Click(object sender, RoutedEventArgs e)
        {
            // Retrieves input values from text boxes.
            string userID = txtBoxUserID.Text;
            string password = txtBoxNewPassword.Text;
            string confirmPassword = txtBoxConfirmPassword.Text;

            // Checks if the passwords match.
            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords must match");
                return;
            }

            // Checks for invalid characters in the password.
            foreach (char character in password)
            {
                if (character == ';' || character == ' ' || character == '"' || character == '\'')
                {
                    MessageBox.Show("Please only include valid characters");
                    return;
                }
            }

            if (userID.Length == 0 || password.Length == 0 || confirmPassword.Length == 0)
            {
                MessageBox.Show("You must input something in each box");
                return;
            }

            // Checks if the password length exceeds the specified limit.
            if (password.Length >= 15)
            {
                MessageBox.Show("Please don't go over 15 characters");
                return;
            }

            // Fetches existing user IDs from the database.
            List<string> userIDs = new List<string>();
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            string selectUserIDs = "SELECT userID FROM ------";  // Change for what table name is relevant
            MySqlCommand cmd = new MySqlCommand(selectUserIDs, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                userIDs.Add(rdr.GetString(0));
            }
            conn.Close();

            // Checks if the provided user ID exists in the database.
            bool userExists = false;
            foreach (string existingUserID in userIDs)
            {
                if (existingUserID == userID)
                {
                    userExists = true;
                    break;
                }
            }

            // Displays an error message if the user ID does not exist.
            if (!userExists)
            {
                MessageBox.Show("This user ID does not exist");
                return;
            }

            // Checks if the new password is the same as the existing password.
            conn = new MySqlConnection(connStr);
            conn.Open();
            string countStatement = "SELECT password FROM ------ WHERE userid = @paramUserID"; // Change for what table name is relevant
            cmd = new MySqlCommand(countStatement, conn);
            cmd.Parameters.AddWithValue("@paramUserID", userID);
            rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                if (password == rdr.GetString(0))
                {
                    MessageBox.Show("That's already your password");
                    return;
                }
            }
            conn.Close();

            // Updates the password in the database.
            conn = new MySqlConnection(connStr);
            conn.Open();
            string updateStatement = "UPDATE ------ " + // Change for what table name is relevant
                "SET password = SHA2(@paramPassword,256) " +
                "WHERE userID = @paramUserID";
            cmd = new MySqlCommand(updateStatement, conn);
            cmd.Parameters.AddWithValue("@paramUserID", userID);
            cmd.Parameters.AddWithValue("@paramPassword", password);

            try
            {
                // Executes the UPDATE command.
                cmd.ExecuteNonQuery();
                MessageBox.Show("Change successful");


                // Change space for opening the new customer window


            }
            catch
            {
                // Displays an error message if the password change is unsuccessful.
                MessageBox.Show("Change unsuccessful");
            }
            conn.Close();
        }

        // Event handler for the "Home" button click.
        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            // Creates a new instance of the MainWindow and shows it.
            MainWindow mainPage = new MainWindow();
            this.Close();
            mainPage.Show();
        }
    }
}
