﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace Occupational_specialism_template // Change for file name
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MySqlConnection conn;
        string connStr = "server=ND-COMPSCI;" + // Home server = 127.0.0.1 - Notre server = ND-COMPSCI
                         "user=" + "TL_S2201563" + ";" +
                         "database=" + "------" + ";" + // Change for whatever schema is given
                         "port=3306;" +
                         "password=" + "Notre151105" + ";";

        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handler for the "Home" button click (empty in the provided code).
        private void btnHome_Click(object sender, RoutedEventArgs e)
        {

        }

        // Method for checking if a string contains invalid characters.
        public static bool validCharacterCheck(string checkVariable)
        {
            foreach (char character in checkVariable)
            {
                // Checks for characters that may pose a security risk in SQL queries.
                if (character == ';' || character == ' ' || character == '"' || character == '\'')
                {
                    return false;
                }
            }
            return true;
        }

        // Event handler for the "Login" button click, performs user authentication.
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            // Retrieves user ID and password from the text boxes.
            string userID = txtUserID.Text;
            string password = txtPassword.Text;

            // Checks if user ID and password contain valid characters.
            bool validUserIDCheck = validCharacterCheck(userID);
            bool validPasswordCheck = validCharacterCheck(password);

            // Displays an error message if invalid characters are detected.
            if (validUserIDCheck == false || validPasswordCheck == false)
            {
                MessageBox.Show("Please only include valid characters");
                return;
            }

            // Establishes a connection to the MySQL database.
            conn = new MySqlConnection(connStr);
            conn.Open();

            // SQL query to check if the provided user ID and password match any records in the '------' table.
            string userCheck = "SELECT * FROM ------ " + // Change for what table name is relevant
                              "WHERE userID = @paramUserID " +
                              "AND password = @paramPassword";

            // Executes the SQL query.
            MySqlCommand cmd = new MySqlCommand(userCheck, conn);
            cmd.Parameters.AddWithValue("@paramUserID", userID);
            cmd.Parameters.AddWithValue("@paramPassword", password);

            MySqlDataReader rdr = cmd.ExecuteReader();

            // Checks if a record is found, indicating successful login.
            if (rdr.Read())
            {
                MessageBox.Show("Login successful");
                txtUserID.Text = String.Empty;
                txtPassword.Text = String.Empty;


                // Change space for opening the new customer window


            }
            else
            {
                // Displays a message if login is unsuccessful.
                MessageBox.Show("Login unsuccessful");
            }

            // Closes the database connection.
            conn.Close();
        }

        // Event handler for the "Register" button click, opens a new registration window.
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            registerWindow registerPage = new registerWindow(this);
            registerPage.Show();
        }

        // Event handler for the "Reset Password" button click, opens a window for resetting the password.
        private void btnResetPassword_Click(object sender, RoutedEventArgs e)
        {
            resetPasswordWindow resetPasswordPage = new resetPasswordWindow(this);
            resetPasswordPage.Show();
        }
    }
}