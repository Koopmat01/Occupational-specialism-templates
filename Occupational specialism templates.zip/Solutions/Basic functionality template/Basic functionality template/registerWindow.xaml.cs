﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Basic_functionality_template
{
    /// <summary>
    /// Interaction logic for registerWindow.xaml
    /// </summary>
    public partial class registerWindow : Window
    {
        // MySqlConnection is part of the MySQL Connector/NET library for connecting to MySQL databases.
        MySqlConnection conn;

        // Connection string that contains information like server, user, database, port, and password.
        // This string is used to establish a connection to the MySQL database.

        string connStr = "server=127.0.0.1;" + // Home server = 127.0.0.1 - Notre server = ND-COMPSCI
                         "user=" + "TL_S2201563" + ";" +
                         "database=" + "tl_s2201563_hag" + ";" +
                         "port=3306;" +
                         "password=" + "Notre151105" + ";";

        // Reference to the parent window that opened this user window.
        Window parentWindow;

        // Constructor for the registerWindow class.
        // Takes a reference to the parent window as a parameter.
        public registerWindow(Window parent)
        {
            // Assigns the parameter to the respective variable.
            this.parentWindow = parent;
            parentWindow.Hide();
            InitializeComponent();
        }

        // Event handler for the "Home" button click.
        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            // Creates a new instance of the MainWindow and shows it.
            MainWindow mainPage = new MainWindow();
            this.Close();
            mainPage.Show();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            // Creates a new instance of the MainWindow and shows it.
            MainWindow mainPage = new MainWindow();
            this.Close();
            mainPage.Show();
        }

        // Method to check if a string is a valid input.
        public static bool validInputCheck(string checkVariable)
        {
            foreach (char character in checkVariable)
            {
                // Checks for invalid characters and returns false if found.
                if (character == ';' || character == ' ' || character == '"' || character == '\'')
                {
                    return false;
                }
            }
            // Checks if input lengths exceed the specified limits.
            if (checkVariable.Length >= 45)
            {
                MessageBox.Show("You went over the character limit");
                return false;
            }

            // Returns true if the string is a valid input
            return true;
        }

        // Event handler for the "Confirm Details" button click.
        private void btnConfirmDetails_Click(object sender, RoutedEventArgs e)
        {
            // Retrieves input values from text boxes.
            string username = txtBoxUsername.Text;
            string password = txtBoxPassword.Text;
            string firstName = txtBoxFirstName.Text;
            string lastName = txtBoxLastName.Text;
            string email = txtBoxEmail.Text;

            // Checks if any of the required fields are empty.
            if (username.Length == 0 || password.Length == 0 || firstName.Length == 0 || lastName.Length == 0 || email.Length == 0)
            {
                MessageBox.Show("You must input something in each box");
                return;
            }

            // Validates input characters for each field.
            bool validUsernameCheck = validInputCheck(username);
            bool validPasswordCheck = validInputCheck(password);
            bool validFirstNameCheck = validInputCheck(firstName);
            bool validLastNameCheck = validInputCheck(lastName);
            bool validEmailCheck = validInputCheck(email);

            // Displays an error message if invalid characters are found.
            if (validUsernameCheck == false || validPasswordCheck == false || validFirstNameCheck == false || validLastNameCheck == false || validEmailCheck == false)
            {
                MessageBox.Show("Please only include valid characters");
                return;
            }

            // Validates that the first name and last name contain only letters.
            if (Regex.IsMatch(firstName, "^[a-zA-Z]+$") == false || Regex.IsMatch(lastName, "^[a-zA-Z]+$") == false)
            {
                MessageBox.Show("Your name can't contain non-letter characters");
                return;
            }

            // Initializes variables for user ID generation.
            int userID = 0;

            // Fetches the total number of users to generate a new user ID.
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            string countStatement = "SELECT COUNT(*) as totalUsers " +
                "FROM users";
            MySqlCommand cmd = new MySqlCommand(countStatement, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                userID = rdr.GetInt32(0);
                userID = userID + 1;
            }
            conn.Close();

            // Inserts the new user into the database.
            conn = new MySqlConnection(connStr);
            conn.Open();
            string insertStatement = "INSERT INTO users (userID, firstName, lastName, username, password, email) " +
                "VALUES " +
                "(@paramUserID,@paramFirstName,@paramLastName,@paramUsername, SHA2(@paramPassword,256) ,@paramEmail)";
            cmd = new MySqlCommand(insertStatement, conn);
            cmd.Parameters.AddWithValue("@paramUserID", userID);
            cmd.Parameters.AddWithValue("@paramFirstName", txtBoxFirstName.Text);
            cmd.Parameters.AddWithValue("@paramLastName", txtBoxLastName.Text);
            cmd.Parameters.AddWithValue("@paramUsername", txtBoxUsername.Text);
            cmd.Parameters.AddWithValue("@paramPassword", txtBoxPassword.Text);
            cmd.Parameters.AddWithValue("@paramEmail", txtBoxEmail.Text);

            try
            {
                // Executes the INSERT command.
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registration successful");
                MessageBox.Show("Your User ID: " + userID);
                string userIDString = Convert.ToString(userID);


                //Change space to open up customer/user window

            }
            catch (Exception ex)
            {
                // Displays an error message if registration is unsuccessful.
                MessageBox.Show(ex.ToString());
                return;
            }
        }
    }
}

