﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Order_window_template
{
    /// <summary>
    /// Interaction logic for customerWindow.xaml
    /// </summary>
    public partial class customerWindow : Window
    {
        // MySqlConnection is part of the MySQL Connector/NET library for connecting to MySQL databases.
        MySqlConnection conn;

        // Connection string that contains information like server, user, database, port, and password.
        // This string is used to establish a connection to the MySQL database.

        string connStr = "server=ND-COMPSCI;" + // Home server = 127.0.0.1 - Notre server = ND-COMPSCI
                         "user=" + "TL_S2201563" + ";" +
                         "database=" + "------" + ";" + // Change for whatever schema is given
                         "port=3306;" +
                         "password=" + "Notre151105" + ";";

        // Reference to the parent window that opened this customer window.
        Window parentWindow;

        // Global variable to store the user ID.
        string customerIDGlobal = "";

        // List to store available product categories.
        List<string> categories;

        MySqlCommand cmd;
        MySqlDataReader rdr;

        // Constructor for the customerWindow class.
        // Takes the user ID and a reference to the parent window as parameters.
        public customerWindow(string customerID, Window parent)
        {
            // Hides the parent window.
            this.parentWindow = parent;
            parentWindow.Hide();

            // Initializes the components of the customer window.
            InitializeComponent();

            // Assigns the user ID to the global variable.
            customerIDGlobal = customerID;

            // Establishes a connection to the MySQL database to retrieve user information.
            conn = new MySqlConnection(connStr);
            conn.Open();

            //Retrieves and displays the user's first and last name.
            string userNameFind = "SELECT firstName, lastName FROM customers WHERE customerID = @customerId";
            MySqlCommand cmd = new MySqlCommand(userNameFind, conn);
            cmd.Parameters.AddWithValue("@customerId", int.Parse(customerID));
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                txtBlockWelcome.Text = $"Hello {rdr.GetString(0)} {rdr.GetString(1)}";
            }
            conn.Close();



            // Initializes the categories list.
            categories = new List<string>();

            // Establishes a connection to the database and retrieves product IDs.
            conn.Open();
            string selectCategories = "SELECT categoryID FROM categories";
            cmd = new MySqlCommand(selectCategories, conn);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                categories.Add(rdr.GetString(0));
            }
            cmbCategories.ItemsSource = categories;
            conn.Close();
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            // Creates a new instance of the MainWindow and shows it.
            MainWindow mainPage = new MainWindow();
            this.Close();
            mainPage.Show();
        }

        private void cmbCategories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            conn.Open();
            string selectCategoriesNames = $"select categoryName from categories where categoryID = {cmbCategories.SelectedValue}";
            cmd = new MySqlCommand(selectCategoriesNames, conn);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                txtBlockOrderLine.Text = $"You've selected the {rdr.GetString(0)} categories";
            }
            conn.Close();

            List<string> products = new List<string>();
            conn.Open();
            string selectProducts = $"SELECT productID FROM products WHERE categoryID = {cmbCategories.SelectedValue}";
            cmd = new MySqlCommand(selectProducts, conn);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                products.Add(rdr.GetString(0));
            }
            cmbItemChoices.ItemsSource = products;
            conn.Close();
        }

        private void cmbItemChoices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbCategories.Text == "")
            {
                MessageBox.Show("Please select a categories first");
                return;
            }
            else
            {
                conn.Open();
                string selectProductNames = $"select productName FROM products where productID = {cmbItemChoices.SelectedValue}";
                cmd = new MySqlCommand(selectProductNames, conn);
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    txtBlockOrderLine.Text = txtBlockOrderLine.Text + "\n" + $"You've selected the {rdr.GetString(0)} item";
                }
                conn.Close();
            }
        }

        private void cmbItemCount_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbItemChoices.Text == "" || cmbCategories.Text == "")
            {
                cmbItemCount.Text = "";
                MessageBox.Show("Please select something from the other boxes first");

                return;
            }
            else
            {
                string itemCount = cmbItemCount.SelectedValue.ToString();
                txtBlockOrderLine.Text = txtBlockOrderLine.Text + "\n" + $"You want {itemCount[itemCount.Length - 1]} of them";
            }
        }

        private void btnCompleteOrder_Click(object sender, RoutedEventArgs e)
        {
            int orderID = 0;
            float productCost = 0;
            float totalCost = 0;

            // Gets the current date and time.
            DateTime currentDateTime = DateTime.Now;
            string currentDateTimeString = currentDateTime.ToString();
            DateTime parsedDate = DateTime.ParseExact(currentDateTimeString, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
            string sqlFormattedDate = parsedDate.ToString("yyyy-MM-dd");

            // Checks if the order details are not empty.
            if (cmbItemCount.Text != "")
            {
                // Establishes a connection to the database and inserts the order details.
                conn = new MySqlConnection(connStr);
                conn.Open();
                string insertOrdersStatement = "insert into orders (customerID, orderDate)" +
                    "values " +
                    "(@paramCustomerID,@paramOrderDate)";
                MySqlCommand cmd = new MySqlCommand(insertOrdersStatement, conn);
                cmd.Parameters.AddWithValue("@paramCustomerID", customerIDGlobal);
                cmd.Parameters.AddWithValue("@paramOrderDate", sqlFormattedDate);
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Part one successful");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Select an item");
            }

            conn = new MySqlConnection(connStr);
            conn.Open();
            string countStatement = "SELECT orderID FROM orders ORDER BY orderID DESC LIMIT 1;";
            cmd = new MySqlCommand(countStatement, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                orderID = rdr.GetInt32(0);
            }
            conn.Close();

            conn = new MySqlConnection(connStr);
            conn.Open();
            string priceFind = "select price from products where productID = @paramProductID ";
            cmd = new MySqlCommand(priceFind, conn);
            cmd.Parameters.AddWithValue("@paramProductID", cmbItemChoices.Text);
            rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                productCost = rdr.GetFloat(0);
                int orderCount;
                int.TryParse(cmbItemCount.Text, out orderCount);
                totalCost = productCost * orderCount;
            }
            conn.Close();

            // Establishes a connection to the database and inserts the order details.
            conn = new MySqlConnection(connStr);
            conn.Open();
            string insertOrderLineStatement = "insert into orderitems (OrderID, ProductID, Quantity, Total) " +
                "values " +
                "(@paramOrderID, @paramProductID, @paramQuantity, @paramTotal)";
            cmd = new MySqlCommand(insertOrderLineStatement, conn);

            cmd.Parameters.AddWithValue("@paramOrderID", orderID);
            cmd.Parameters.AddWithValue("@paramProductID", int.Parse(cmbItemChoices.Text));
            cmd.Parameters.AddWithValue("@paramQuantity", int.Parse(cmbItemCount.Text));
            cmd.Parameters.AddWithValue("@paramTotal", totalCost);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Addition successful");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            // Clears the combo box selections and order line text.
            cmbCategories.Text = String.Empty;
            cmbItemChoices.Text = String.Empty;
            cmbItemCount.Text = String.Empty;
            txtBlockOrderLine.Text = "";

            conn.Close();
        }
    }
}
